NOTE: Due to lack of time I wasn't able to debug the better_algo.py and even_better algorithm but intuition is given below
To run:
use: python3 main.py /dir/to/wordfile <word>
i.e python3 main.py word_list.py god

runtime analysis:
O(mxnlog(n)) description in the code
we can even make it better by converting list into dictionary. The dictionary is hash table and lookup would be o(1)
Steps to do it:
step1:
def findanagram(search: str, filename):
    letter_dict: dictionary[str] = {}
    key_values = []
    for letter in search:
        if letter not in letter_dict:
            letter_dict[letter] = 1
        else:
            letter_dict[letter] += 1
    for keys in letter_dict:
        key_values.append(0)   #creates the value so we can check how many times certain number occurs

step2:
def anagram(word: str, search: dictionary[str], key_list):
    """Return true if all the letter matches with the word"""
    for letter in word:
        if letter not in search or search[letter]==key_list[search.keys().index(letter)]:
            return False
           # removes letter once they have been used for repeatition
        key_list[search.keys().index(letter)]+=1   #No need to worry if it doesn't exist
    return True

The only thing better in this algorithm is time for searching the word so really the algorithm is O(mxn)
We can even do it better by converting the words into all the permutation of the words and check if it exists in the dictionary of words
except for words of the list.

Generating the permutation:
    O(nlogn)
    word_list_straight = []
    word_list_back = []
    for start in range(len(words)):
        for end in range(len(words)):
            if start!=0 or end==len(words)-1:   # the only way this would be true is start=0 and end=word_length-1
                word_list_straight.append(words[start:end])
                word_list_back.append(words[end:start])

            else:
                word_list_back.append(words[end:start])
checking is o(1) because dictionary:
    so total time O(nlogn * num_permutations)

