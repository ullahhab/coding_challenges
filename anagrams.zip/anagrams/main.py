# Anagram Program
import sys


def openfile(filename: str):
    """Opens file and returns a each word splited into newline"""
    file = open(filename, "r")   #opens the file
    file: list[str] = file.read()  #reads from the file
    file: list[str] = file.split("\n") #splits each word by line
    return file

#This depends on word and orientation so upper bound would be lenght of the word i.e letters so O(len(word))
# For simplicity we can say o(nlogn)
def anagram(word: str, search: list[str]):
    """Return true if all the letter matches with the word"""
    for letter in word:
        if letter not in search:
            return False
        search.pop(search.index(letter))   # removes letter once they have been used for repeatition
    return True

#Number of words so O(m)
def findanagram(search: str, filename):
    """Finds anagram and sub anagram"""
    letter_list: list[str] = []
    for letter in search:
        letter_list.append(letter)
    letter_list: list[str] = tuple(letter_list)

    words_list: str = openfile(filename)  # opens file
    for word in words_list:
        if word == search:
            continue
        elif len(word) <= len(search):  # Only checks for the word less than or equal to the length
            if anagram(word, list(letter_list)):
                print(word)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Wrong values provided: python3 main.py <word_file> <word>")
    else:
        #Total run time with upper bound is O(mxnlog(n))
        findanagram(sys.argv[2], sys.argv[1])
