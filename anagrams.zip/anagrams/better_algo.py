# Anagram Program
import sys


def openfile(filename: str):
    """Opens file and returns a each word splited into newline"""
    file = open(filename, "r")  # opens the file
    file: list[str] = file.read()  # reads from the file
    file: list[str] = file.split("\n")  # splits each word by line
    return file


# This depends on word and orientation so upper bound would be lenght of the word i.e letters so O(len(word))
# For simplicity we can say o(nlogn)
def anagram(word: str, search, key_list):
    """Return true if all the letter matches with the word"""
    for letter in word:
        if letter not in search or search[letter] == key_list[list(search.keys()).index(letter)]:
            return False
        # removes letter once they have been used for repeatition
        print(key_list[list(search.keys()).index(letter)])
        key_list[list(search.keys()).index(letter)] += 1  # No need to worry if it doesn't exist
    return True


# Number of words so O(m)
def findanagram(search: str, filename):
    letter_dict = {}
    key_values = []
    for letter in search:
        if letter not in letter_dict:
            letter_dict[letter] = 1
        else:
            letter_dict[letter] += 1
    for keys in letter_dict:
        key_values.append(0)  # creates the value so we can check how many times certain number occurs

    words_list: str = openfile(filename)  # opens file
    for word in words_list:
        if word == search:
            continue
        elif len(word) <= len(search):  # Only checks for the word less than or equal to the length
            if anagram(word, letter_dict, key_values):
                print(word)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Wrong values provided: python3 main.py <word_file> <word>")
    else:
        # Total run time with upper bound is O(mxnlog(n))
        findanagram(sys.argv[2], sys.argv[1])
